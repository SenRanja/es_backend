# encoding=utf-8

from openpyxl import load_workbook

wb = load_workbook("experi.xlsx", read_only=True)
# 获取 sheet 列表
# sheet_names = wb.sheetnames
# 获取第一张工作表
my_sheet = wb.worksheets[0]
print(my_sheet.title)
# 行数
print(my_sheet.max_row)
# 列数
print(my_sheet.max_column)

FIRST_ROW_FLAG = True

# 按行读取: 按 A1、B1、C1 顺序返回
# for row in my_sheet.rows:
#     for cell in row:
#         print(cell.value)

# 从第二行开始读取
for row in my_sheet.iter_rows(min_row=2, values_only=True):
    for cell_value in row:
        print(cell_value)

# 按列读取: 按 A1、A2、A3 顺序返回
# for column in my_sheet.columns:
#     for cell in column:
#         print(cell.value)

# 写 workbook
# from openpyxl import Workbook
# # 新建一个新的工作表（未保存）。
# wb = Workbook()
# # 只写模式
# wb = Workbook(write_only=True)
# # 保存文件，若加载路径与保存的路径一致将会被覆盖
# wb.save(r"F:\sample.xlsx")
# # 将文件作为模板保存 as_template 默认为 False
# wb.save("template.xltx", as_template=True)