# encoding=utf-8
from django.core.files.base import File

__all__ = ['File']
