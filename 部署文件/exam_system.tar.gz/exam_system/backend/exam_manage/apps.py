# encoding=utf-8
from django.apps import AppConfig


class ExamManageConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'exam_manage'
