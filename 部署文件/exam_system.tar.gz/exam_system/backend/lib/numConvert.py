# encoding=utf-8

def float2int(num:float):
    if int(num)==num:
        return int(num)
    else:
        return num