# encoding=utf-8
from django.apps import AppConfig


class SubjectManageConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'subject_manage'
